
/**
 * Title:        <p>
 * Description:  <p>
 * Copyright:    Copyright (c) <p>
 * Company:      <p>
 * @author
 * @version 1.0
 */
package lab3;

import java.awt.*;
import java.awt.Canvas;

public class GameBoard extends Canvas
{
  public void draw()
  {
    Graphics g;
    int gameState[][] = GameGrid.getGameState();

    for(int x = 0; x < 7; x++)
      for(int y = 0; y < 6; y++)
        switch(gameState[x][y])
        {
          case 0:
            break;
          case 1:
            g.setColor(Color.yellow);
            g.fillOval ((7*x / FourInRow.getGameFrame().getWidth()),
                       (7*y / FourInRow.getGameFrame().getWidth()),10,10);
            break;
          case 2:
            g.setColor(Color.red);
            g.fillOval ((7*x / FourInRow.getGameFrame().getWidth()),
                       (7*y / FourInRow.getGameFrame().getWidth()),10,10);
            break;
        }
  }

  public int getUserClickColumn()
  {
    final int column;
    MouseListener ml = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {
        column = 7 * e.getX() / FourInRow.getGameFrame().getWidth();
      }
    };

    return column;
  }
}