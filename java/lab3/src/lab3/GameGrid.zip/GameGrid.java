
/**
 * Title:        <p>
 * Description:  <p>
 * Copyright:    Copyright (c) <p>
 * Company:      <p>
 * @author
 * @version 1.0
 */
package lab3;

import java.lang.Exception;

public class GameGrid
{
  static int[][] GameMatrix=new int[6][7];

  public void clear(){//Nollar alla f�lt i matrisen
    for(int i=0; i<6; i++)
      for(int j=0; j<7; j++)
        GameMatrix[i][j]=0;
  }

  //Look up position ; retunera radnummer
  static int LookupPosition(int column){ //column kommer fr�n player
    int i =7;//kanske n�gon konstant?
    while (GameMatrix[column][i]!=0)
      i--;   // Letar upp f�rsta tomma position i kolumnen
    return i;
  }

  static int insertMarker(int column, int row, int playerColor){
  GameMatrix[column][row]=playerColor;//colur=spelarens f�rg
  }

  public int[][] getGameState(){
    return GameMatrix;
  }



  public void DoMove(int column, int playerColor)
    throws InvalidMoveException{
    int row;
    if (column<=7){
      row=LookupPosition(column);
      insertMarker(column,row,playerColor);
    }
    else throw new InvalidMoveException();
  }

}